from controller.MainWindowController import MainWindowController

if __name__ == "__main__":
	MainWindowController()